---
name: PakVet Clinical System
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#3f4941'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#6f7a70'
  outline-variant: '#bec9be'
  surface-tint: '#006d3e'
  primary: '#006036'
  on-primary: '#ffffff'
  primary-container: '#1b7a4a'
  on-primary-container: '#abffc6'
  inverse-primary: '#80d9a0'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#764900'
  on-tertiary: '#ffffff'
  tertiary-container: '#965f00'
  on-tertiary-container: '#ffe9d4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf6ba'
  primary-fixed-dim: '#80d9a0'
  on-primary-fixed: '#00210f'
  on-primary-fixed-variant: '#00522e'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 4.25rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.005em
  title-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves a modern, dual-purpose veterinary health platform catering to urban pet parents, rural livestock owners, and licensed veterinary pharmacists across Pakistan. The emotional landscape balances stringent medical rigor with gentle, compassionate care. It replaces anxiety and transactional coldness with reassurance, scientific authority, and immediate clarity.

The visual direction combines **Modern Clinical Minimalism** with **Warm Tactile Precision**:
- **Purity & Trust:** Medical-grade clarity achieved through generous spacing, balanced tonal surfaces, and zero visual clutter.
- **Empathetic Utility:** Rounded interactive touchpoints, high-contrast action triggers, and tactile pill selectors designed to feel approachable for non-technical handlers.
- **Bilingual Symbiosis:** Built from the ground up for seamless bidirectional rendering (English LTR and Urdu RTL Nastaliq/Naskh adaptations) without breaking visual weight or layout equilibrium.

## Colors

The palette establishes an immediate sense of biological health, antiseptic safety, and operational reliability.

- **Primary Emerald (`#1B7A4A`):** The cornerstone of the brand identity, symbolizing vibrant life, deep veterinary trust, and national alignment. Used for primary navigation markers, verified clinical badges, key data headers, and secure checkout indicators.
- **Secondary Medical Teal (`#0D9488`):** Denotes active clinical care, pharmacy certifications, medication tags, and secondary action highlights.
- **Tertiary Amber Accent (`#F59E0B`):** Reserved exclusively for high-intent conversion pathways: emergency hotline triggers, "Book Vet Consultation", "Refill Prescription", and critical cart actions. It provides sharp contrast against the mint and white foundation without aggressive alarmist tones.
- **Neutral Dark Slate (`#1E293B`):** Replaces generic black to provide maximum text legibility and soft contrast against crisp white and mint backgrounds.
- **Surface Foundations:** 
  - Canvas: Soothing Mint (`#F4FBF7`) to relieve optical fatigue during long browsing and data entry sessions.
  - Cards & Containers: Crisp Pure White (`#FFFFFF`) to pop out functional units distinctly.
  - Border/Divider Wash: Soft sage-tinted neutral (`#E2EFE9`).

## Typography

Typography pairs the human-centric geometry of **Plus Jakarta Sans** for prominent headers with the utilitarian clarity of **Inter** for dense medication tables, dosages, prescription cards, and patient history logs.

### Bilingual Handling (English & Urdu)
- When switching to Urdu, line-height automatically expands by a factor of 1.25x across all typographic scale tokens to accommodate vertical Nastaliq descenders without clipping.
- Headline weight decreases by one increment (e.g., Bold to SemiBold) in Urdu scripts to retain legibility at small rendering points.
- Numerical units for pharmaceutical dosages (mg, ml, cc) maintain fixed non-proportional tabular lining for critical patient safety.

## Layout & Spacing

The layout is grounded in a 12-column responsive fluid grid built around an 8pt base grid unit.

### Form Factor Adaptations
- **Desktop (1200px+):** 12-column grid, 24px (`gutter`) column gaps, 32px (`margin`) outer margins with a maximum canvas width of 1440px. Sidebars for livestock category filters and clinical order states remain pinned.
- **Tablet (768px - 1199px):** 8-column grid, 20px gutters, 24px outer margins. Multi-step clinic booking wizards consolidate to single-column flows.
- **Mobile (< 768px):** 4-column fluid grid, 16px (`gutter-mobile`) gutters, 16px (`margin-mobile`) outer margins. Navigation pivots to a bottom navigation rail optimized for single-handed veterinary field operation.

### Rhythmic Discipline
- `space-xs` (4px) and `space-sm` (8px): Used strictly for internal chip padding, input label separation, and icon-to-text gaps.
- `space-md` (16px): Standard inner card padding and field stack spacing.
- `space-lg` (24px): Card-to-card stacking in prescription grids and inventory sections.
- `space-xl` (40px): Section breaks between clinic service modules and product carousels.

## Elevation & Depth

Visual hierarchy rejects exaggerated, heavy drop-shadows in favor of an **antiseptic, ambient elevation model** layered with subtle emerald-tinted containment.

- **Level 0 (Flat Base):** Soothing Mint canvas (`#F4FBF7`). No shadow, no border.
- **Level 1 (Clinical Cards & Panels):** Solid crisp white (`#FFFFFF`) with a 1px perimeter border in `#E2EFE9` and a whisper-soft ambient floor: `box-shadow: 0 2px 8px -2px rgba(27, 122, 74, 0.04), 0 1px 3px 0 rgba(0, 0, 0, 0.02)`.
- **Level 2 (Interactive Cards & Popovers):** Elevated on hover or active state: `box-shadow: 0 10px 25px -5px rgba(27, 122, 74, 0.08), 0 4px 10px -2px rgba(0, 0, 0, 0.03)`.
- **Level 3 (Modals, Prescription Drawers & Floating Action Buttons):** `box-shadow: 0 20px 35px -8px rgba(30, 41, 59, 0.12), 0 8px 16px -4px rgba(30, 41, 59, 0.04)`.
- **Backdrop Overlays:** Clinical modals use a diffused backdrop filter: `backdrop-filter: blur(6px); background: rgba(30, 41, 59, 0.4)`.

## Shapes

The design system adopts a balanced **Rounded (`2`)** shape architecture, striking the exact intersection between clinical cleanliness and gentle pet/livestock care.

- **Cards, Modals & Field Containers:** Governed by `rounded-md` (0.5rem / 8px) to `rounded-lg` (1rem / 16px), generating neat, organized compartments that convey stability.
- **Pills & Selectors:** Buttons, category chips, status tags, and dosage toggles utilize full capsule geometry (`rounded-full` / 9999px) to soften the interface and encourage effortless touch interaction.
- **Avatars & Species Badges:** Livestock and pet thumbnail portraits sit within circular masks (`rounded-full`), while pharmaceutical packaging photos occupy structured `rounded-md` bounding boxes.

## Components

### Buttons
- **Primary Conversion (Amber):** Solid `#F59E0B` with `#FFFFFF` text (SemiBold). Hover shifts to `#D97706`. Height: 48px desktop / 44px mobile. Full pill radius (`rounded-full`) with subtle active press compression (`scale(0.98)`).
- **Clinical Primary (Emerald):** Solid `#1B7A4A` with `#FFFFFF` text. Used for booking confirmations, cart additions, and doctor approvals. Hover shifts to `#15633C`.
- **Secondary (Teal Outline):** 1.5px border in `#0D9488`, transparent background, `#0D9488` text. Hover fills with 8% `#0D9488` tint.
- **Tertiary/Ghost:** Transparent background with `#1E293B` text, shifting to mint wash (`#EBF7F1`) on hover.

### Chips & Pill Filters
- **Filter Chips:** Height 36px. Pill shape (`rounded-full`). Unselected state: `#FFFFFF` background, 1px border `#E2EFE9`, `#1E293B` text. Selected state: `#1B7A4A` background with crisp white text and checkmark indicator.
- **Species Badges (Bovine, Equine, Canine, Feline, Avian):** Pill-shaped, composed of a 20px round species icon paired with dual-language micro-labels (e.g., "Dairy Cattle / گائے").

### Prescription & Clinical Cards
- Pure `#FFFFFF` surface, 16px inner padding, `rounded-lg` (16px), 1px `#E2EFE9` border.
- **Badge Indicators:** Embedded verified badges in top right (or top left in RTL). Green dot (`#1B7A4A`) for "In Stock / OTC", Amber badge (`#F59E0B`) for "Rx Required / نسخہ درکار".
- **Micro-Metrics:** Tabular representation of dosage volume, storage temperature, and expiry dates using `body-sm` in `#64748B`.

### Input Fields & Search Bars
- **Text Inputs:** Height 48px, `rounded-md` (8px), background `#FFFFFF`, border 1px solid `#CBD5E1`. Focused state: 2px ring in `#0D9488` with zero outer offset.
- **Veterinary Search Input:** Integrated species filter selector attached to the leading edge of the bar, full-length responsive field with high-contrast amber search button pinned on the trailing edge.

### Checkboxes & Radio Buttons
- 20px square (`rounded-sm`) for checkboxes, 20px circle for radio controls.
- Active fill: `#1B7A4A` with pure white central glyphs. Inactive state: `#FFFFFF` with `#94A3B8` border (1.5px).

### Clinical Status Banners
- **Urgent/Recall:** Soft red background (`#FEF2F2`), red text (`#991B1B`), left border 4px solid `#DC2626`.
- **Consultation Active:** Soft teal background (`#F0FDFA`), teal text (`#0F766E`), left border 4px solid `#0D9488`.